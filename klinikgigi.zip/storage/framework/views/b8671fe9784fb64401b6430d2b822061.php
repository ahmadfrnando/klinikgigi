

<?php $__env->startSection('title', 'Jadwal Pengobatan'); ?>

<?php $__env->startSection('content'); ?>

    <section class="my-10 mx-20">
        <h1 class="text-3xl font-bold text-center mb-8">Data Penjadwalan Pengobatan Gigi</h1>
        <div class="mx-auto w-96 p-2 flex items-center justify-center">
            <form action="<?php echo e(route('admin.pengobatan.edit', $pengobatan->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-4 flex items-center gap-3">
                    <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Tanggal</label>
                    <input type="date" name="tanggal" value="<?php echo e($pengobatan->tanggal); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                    <button type="submit"><img src="<?php echo e(asset('save.svg')); ?>" class="h-10 w-10"></button>
                </div>
                <div class="mb-4 flex items-center gap-3">
                    <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Nama</label>
                    <input type="text" name="nama" value="<?php echo e($pengobatan->nama); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                <div class="mb-4 flex items-center gap-3">
                    <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Jam</label>
                    <input type="time" name="jam" value="<?php echo e($pengobatan->jam); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                <div class="mb-4 flex items-center gap-3">
                    <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Jenis Pengobatan</label>
                    <input type="text" name="jenis_pengobatan_gigi" value="<?php echo e($pengobatan->jenis_pengobatan_gigi); ?>"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                <div class="mb-4 flex items-center gap-3">
                    <label class="text-gray-700 uppercase text-sm font-bold mb-2 w-52">Status</label>
                    <select name="status"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="Sedang Diproses" <?php echo e($pengobatan->status == 'Sedang Diproses' ? 'selected' : ''); ?>>
                            Sedang Diproses</option>
                        <option value="Diterima" <?php echo e($pengobatan->status == 'Diterima' ? 'selected' : ''); ?>>Diterima</option>
                        <option value="Ditolak(Pilih Jadwal Lain)"
                            <?php echo e($pengobatan->status == 'Ditolak(Pilih Jadwal Lain)' ? 'selected' : ''); ?>>Ditolak(Pilih Jadwal
                            Lain)</option>
                    </select>
                </div>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\klinikgigi\resources\views\admin\pengobatan-edit.blade.php ENDPATH**/ ?>