

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
     
    <section class="bg-no-repeat bg-gray-700 bg-blend-multiply"
        style="background-image: url('<?php echo e(asset('jumbotron.jpg')); ?>'); background-size: cover; height: 700px">
        <div class="px-4 mx-auto max-w-screen-xl text-center py-24 lg:py-56">
            <h1 class="mb-4 text-4xl font-extrabold tracking-tight leading-none text-white md:text-5xl lg:text-6xl">
                Meilani Sinaga</h1>
            <p class="mb-8 text-lg font-normal text-gray-300 lg:text-xl sm:px-16 lg:px-48 uppercase tracking-[0.2em]">
                Penjadwalan konsultasi dan pengobatan gigi
            </p>
            <div class="flex flex-col space-y-4 sm:flex-row sm:justify-center sm:space-y-0">
                <a href="<?php echo e(route('admin.home')); ?>"
                    class="inline-flex uppercase tracking-widest justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-900">
                    Welcome
                </a>
            </div>
        </div>

        <div class="flex gap-20 items-center justify-center w-full">
            <a href="<?php echo e(route('admin.jadwaldokter')); ?>"
                class="flex items-center gap-4 max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100">
                <img src="<?php echo e(asset('jadwal1.svg')); ?>" class="h-20 w-20">
                <h5 class="mb-2 text-2xl uppercase tracking-widest text-gray-900">Jadwal Dokter</h5>
            </a>
            <a href="<?php echo e(route('admin.pasien')); ?>"
                class="flex items-center gap-4 max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100">
                <img src="<?php echo e(asset('pasien.svg')); ?>" class="h-20 w-20">
                <h5 class="mb-2 text-2xl uppercase tracking-widest text-gray-900">Pasien</h5>
            </a>
            <a href="<?php echo e(route('admin.pengobatan')); ?>"
                class="flex items-center gap-4 max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100">
                <img src="<?php echo e(asset('jadwal2.svg')); ?>" class="h-20 w-20">
                <h5 class="mb-2 text-2xl uppercase tracking-widest text-gray-900">Penjadwalan</h5>
            </a>
        </div>

    </section>

    <section class="my-32">
        <div class="flex gap-10 justify-center">
            <div class="block max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100">
                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900">Penjadwalan</h5>
                <p class="font-normal text-gray-700 dark:text-gray-400">Penjadwalan adalah pembagian waktu berdasarkan rencana pengaturan urutan kerja, daftar atau tabel kegiatan atau rencana kegiatan dengan pembagian waktu pelaksanaan yang terperinci.</p>
            </div>
            <div class="block max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100">
                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900">Konsultasi</h5>
                <p class="font-normal text-gray-700 dark:text-gray-400">Konsultasi tidak ada rumusan resmi tentang pengertian konsultasi, namun konsultasi dapat diartikan sebagai sesuatu hal yang bersifat personal antara satu pihak (klien) dengan pihak lain yang lazim.</p>
            </div>
            <div class="block max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100">
                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900">Pengobatan Gigi</h5>
                <p class="font-normal text-gray-700 dark:text-gray-400">pengobatan gigi merupakan jenis pengobatan yang menggunakan alat, cara, dan bahan yang berkaitan dengan gigi.</p>
            </div>
        </div>

    </section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\klinikgigi\resources\views\admin\home.blade.php ENDPATH**/ ?>