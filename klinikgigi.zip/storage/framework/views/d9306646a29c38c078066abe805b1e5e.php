<textarea
    name="<?php echo e($name); ?>"
    id="<?php echo e($id); ?>"
    rows="<?php echo e($rows); ?>"
    <?php echo e($attributes); ?>

><?php echo e(old($name, $slot)); ?></textarea>
<?php /**PATH D:\application\klinikgigi\vendor\blade-ui-kit\blade-ui-kit\resources\views\components\forms\inputs\textarea.blade.php ENDPATH**/ ?>