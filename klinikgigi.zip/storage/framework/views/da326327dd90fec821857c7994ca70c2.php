<input
    name="<?php echo e($name); ?>"
    type="email"
    id="<?php echo e($id); ?>"
    <?php if($value): ?>value="<?php echo e($value); ?>"<?php endif; ?>
    <?php echo e($attributes); ?>

/>
<?php /**PATH D:\application\klinikgigi\vendor\blade-ui-kit\blade-ui-kit\resources\views\components\forms\inputs\email.blade.php ENDPATH**/ ?>