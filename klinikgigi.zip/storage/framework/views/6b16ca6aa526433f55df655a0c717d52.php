<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjadwalan Pengobatan Gigi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th,
        table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #4CAF50;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: #ddd;
        }

        table td {
            color: #333;
        }

        .ttd-container {
            display: flex;
            justify-content: space-between;
            margin-top: 50px;
        }

        .ttd-section {
            text-align: center;
            margin-top: 50px;
        }

        .ttd-section p {
            margin-bottom: 80px;
        }

        .ttd-section .name {
            text-decoration: underline;
            font-weight: bold;
        }

    </style>
</head>

<body>
    <h1>Data Penjadwalan Pengobatan Gigi</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Jam</th>
                <th>Jenis Pengobatan</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pengobatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->tanggal); ?></td>
                <td><?php echo e($item->nama); ?></td>
                <td><?php echo e($item->jam); ?></td>
                <td><?php echo e($item->jenis_pengobatan_gigi); ?></td>
                <td><?php echo e($item->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="ttd-container">
        <div class="ttd-section">
            <p>Medan, <?php echo e($currentDate); ?></p>
            <p>_________________</p>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\application\klinikgigi\resources\views\admin\pengobatanpdf.blade.php ENDPATH**/ ?>