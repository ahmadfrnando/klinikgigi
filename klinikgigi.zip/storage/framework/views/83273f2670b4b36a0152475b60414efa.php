

<?php $__env->startSection('title', 'Jadwal Pengobatan'); ?>

<?php $__env->startSection('content'); ?>

    <section class="my-10 mx-20">
        <h1 class="text-3xl font-bold text-center mb-8">Data Penjadwalan Pengobatan Gigi</h1>
        <div class="flex justify-start py-2 px-4 gap-2">
            <form action="<?php echo e(route('admin.pengobatan.filter')); ?>" method="GET" class="flex gap-4">
                <?php echo csrf_field(); ?>
                <div>
                    <input type="date" id="set_date" name="set_date" class="px-3 py-2 border rounded-lg">
                </div>
                <div class="flex items-end">
                    <button type="submit" class="bg-gray-500 text-white px-4 py-2 rounded-lg">Set</button>
                </div>
                <div class="flex items-end">
                    <a href="#" onclick="submitCetakForm()" class="bg-gray-500 text-white px-4 py-2 rounded-lg">Cetak</a>
                </div>
            </form>
        </div>
        <script>
            function submitCetakForm() {
                const date = document.getElementById('set_date').value;
                const url = date ? `<?php echo e(url('admin/cetakpdf')); ?>?set_date=${date}` : `<?php echo e(url('admin/cetakpdf')); ?>`;
                window.open(url, '_blank');
            }
        </script>
        <div class="overflow-x-auto">
            <form action="<?php echo e(route('admin.pengobatan.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="flex gap-2 items-center py-2 px-4">
                    <input type="date" name="tanggal" placeholder="tanggal"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                    <select name="nama"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option disabled>Pilih Pasien</option>
                        <?php $__currentLoopData = $nama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($namas->nik); ?>-<?php echo e($namas->name); ?>"><?php echo e($namas->nik); ?>-<?php echo e($namas->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="time" name="jam" placeholder="Jam"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                    <select name="jenis_pengobatan_gigi"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option disabled>Pilih Jenis Pengobatan</option>
                        <option value="Pasang Behel">Pasang Behel</option>
                        <option value="Bersihin Karang">Bersihkan Karang</option>
                        <option value="Kontrol Behel">Kontrol Behel</option>
                        <option value="Konsultasi">Konsultasi</option>
                        <option value="Cabut Gigi">Cabut Gigi</option>
                        <option value="Cabut Gigi">Tambal Gigi</option>
                        <option value="Cabut Gigi">Tambah Gigi Palsu</option>
                    </select>
                    <button type="submit"><img src="<?php echo e(asset('save.svg')); ?>" class="w-[200px]"></button>
                </div>
            </form>
            <table class="min-w-full bg-white border border-gray-200">
                <thead class="bg-black">
                    <tr>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">ID</th>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Tanggal
                            Pengobatan</th>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Nama
                            Pasien</th>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Jam</th>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Jenis
                            Pengobatan</th>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Status
                        </th>
                        <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Aksi
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Row 1 -->
                    <?php $__currentLoopData = $pengobatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">

                            <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($no++); ?></td>
                            <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->tanggal); ?></td>
                            <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->nama); ?></td>
                            <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->jam); ?></td>
                            <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700">
                                <?php echo e($item->jenis_pengobatan_gigi); ?></td>
                            <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->status); ?></td>
                            <td class="py-3 px-4 border-b border-gray-200 text-sm flex gap-6">
                                <a href="<?php echo e(route('admin.pengobatan.show', $item->id)); ?>"><img
                                        src="<?php echo e(asset('save.svg')); ?>" class="h-8 w-8"></a>
                                <a href="<?php echo e(route('admin.pengobatan.delete', $item->id)); ?>"><img
                                        src="<?php echo e(asset('delete.svg')); ?>" class="h-8 w-8"></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\klinikgigi\resources\views\admin\pengobatan.blade.php ENDPATH**/ ?>