

<?php $__env->startSection('title', 'Jadwal Pengobatan'); ?>

<?php $__env->startSection('content'); ?>
     
<section class="my-10 mx-20">
    <h1 class="text-3xl font-bold text-center mb-8">Data Jadwal Pengobatan</h1>
    <div class="mx-auto w-96 p-2 flex items-center justify-center">
        <form action="<?php echo e(route('user.pengobatan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4 flex items-center gap-3">
                <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Tanggal</label>
                <input type="date" name="tanggal"
                    class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <button type="submit"><img src="<?php echo e(asset('save.svg')); ?>" class="h-10 w-10"></button>
            </div>
            <div class="mb-4 flex items-center gap-3">
                <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Nama</label>
                <select name="nama" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                    <option disabled>Pilih Pasien</option>
                        <?php $__currentLoopData = $nama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($namas->nik); ?>-<?php echo e($namas->name); ?>"><?php echo e($namas->nik); ?>-<?php echo e($namas->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-4 flex items-center gap-3">
                <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Jam</label>
                <input type="time" name="jam" 
                    class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>
            <div class="mb-4 flex items-center gap-3">
                <label class=" text-gray-700 uppercase text-sm font-bold mb-2 w-52">Jenis Pengobatan Gigi</label>
                <select name="jenis_pengobatan_gigi" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                    <option disabled>Pilih Jenis Pengobatan</option>
                        <option value="Pasang Behel">Pasang Behel</option>
                        <option value="Bersihin Karang">Bersihkan Karang</option>
                        <option value="Kontrol Behel">Kontrol Behel</option>
                        <option value="Konsultasi">Konsultasi</option>
                        <option value="Cabut Gigi">Cabut Gigi</option>
                        <option value="Cabut Gigi">Tambal Gigi</option>
                        <option value="Cabut Gigi">Tambah Gigi Palsu</option>
                </select>
            </div>
        </form>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-200">
            <thead class="bg-black">
                <tr>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Tanggal Pengobatan</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Nama Pasien</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Jam</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Jenis Pengobatan</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Status</th>
                </tr>
            </thead>
            <tbody>
                <!-- Row 1 -->
                <?php $__currentLoopData = $pengobatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->tanggal); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->nama); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->jam); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->jenis_pengobatan_gigi); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->status); ?></td>
                    
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\klinikgigi\resources\views/user/pengobatan.blade.php ENDPATH**/ ?>