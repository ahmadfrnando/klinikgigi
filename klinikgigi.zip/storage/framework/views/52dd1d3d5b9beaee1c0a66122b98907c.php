<div wire:ignore>
    <input
        x-data="{
            picker: null,
        }"
        x-init="$nextTick(() => { 
            if (picker) return;
                
            picker = flatpickr($root, <?php echo e($jsonOptions()); ?>);
        })"
        name="<?php echo e($name); ?>"
        type="text"
        id="<?php echo e($id); ?>"
        placeholder="<?php echo e($placeholder); ?>"
        <?php if($value): ?> value="<?php echo e($value); ?>" <?php endif; ?>
        <?php echo e($attributes); ?>

    />
</div>
<?php /**PATH D:\application\klinikgigi\vendor\blade-ui-kit\blade-ui-kit\resources\views\components\forms\inputs\flat-pickr.blade.php ENDPATH**/ ?>