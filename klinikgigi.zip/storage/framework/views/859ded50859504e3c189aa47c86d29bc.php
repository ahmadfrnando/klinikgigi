<input
    name="<?php echo e($name); ?>"
    type="password"
    id="<?php echo e($id); ?>"
    <?php echo e($attributes); ?>

/>
<?php /**PATH D:\application\klinikgigi\vendor\blade-ui-kit\blade-ui-kit\resources\views\components\forms\inputs\password.blade.php ENDPATH**/ ?>