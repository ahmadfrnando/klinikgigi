

<?php $__env->startSection('title', 'Jadwal Dokter'); ?>

<?php $__env->startSection('content'); ?>
     
<section class="my-10 mx-20">
    <h1 class="text-3xl font-bold text-center mb-8">Data Jadwal Dokter</h1>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-200">
            <thead class="bg-black">
                <tr>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">ID</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Nama Dokter</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Hari</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Jam</th>
                </tr>
            </thead>
            <tbody>
                <!-- Row 1 -->
                <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($no++); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->nama); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->hari); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->jam); ?></td>
                    
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\klinikgigi\resources\views\user\jadwaldokter.blade.php ENDPATH**/ ?>