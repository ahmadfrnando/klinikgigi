<div <?php echo e($attributes); ?>>
    <?php echo $toHtml($slot); ?>

</div>
<?php /**PATH D:\application\klinikgigi\vendor\blade-ui-kit\blade-ui-kit\resources\views\components\markdown\markdown.blade.php ENDPATH**/ ?>