

<?php $__env->startSection('title', 'Jadwal Dokter'); ?>

<?php $__env->startSection('content'); ?>

<section class="my-10 mx-20">
    <h1 class="text-3xl font-bold text-center mb-8">Data Jadwal Dokter</h1>
    <div class="overflow-x-auto">
        <form action="<?php echo e(route('admin.jadwaldokter.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="flex gap-2 items-center py-2 px-4">
                <input type="text" name="nama" placeholder="Nama Dokter" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <input type="text" name="hari1" placeholder="Hari" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <span>sd</span>
                <input type="text" name="hari2" placeholder="Hari" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <input type="time" name="jam1" placeholder="Jam" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <span>sd</span>
                <input type="time" name="jam2" placeholder="Jam" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                <button type="submit" class="bg-red-500"><img src="<?php echo e(asset('save.svg')); ?>" class="w-[200px]"></button>
            </div>
        </form>
        <table class="min-w-full bg-white border border-gray-200">
            <thead class="bg-black">
                <tr>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">ID</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Nama Dokter</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Hari</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Jam</th>
                    <th class="py-3 px-4 border-b border-gray-200 text-left text-sm font-semibold text-white">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Row 1 -->
                <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($no++); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->nama); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->hari); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo e($item->jam); ?></td>
                    <td class="py-3 px-4 border-b border-gray-200 text-sm flex gap-6">
                        <a href="<?php echo e(route('admin.jadwaldokter.show', $item->id)); ?>"><img src="<?php echo e(asset('save.svg')); ?>" class="h-8 w-8"></a>
                        <a href="<?php echo e(route('admin.jadwaldokter.delete', $item->id)); ?>"><img src="<?php echo e(asset('delete.svg')); ?>" class="h-8 w-8"></a>
                    </td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\klinikgigi\resources\views\admin\jadwal-dokter.blade.php ENDPATH**/ ?>